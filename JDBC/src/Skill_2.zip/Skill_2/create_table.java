package Skill_2;
import java.sql.*;
import java.sql.Statement;


public class create_table 
{

	public static void main(String[] args)throws Exception
	{
		try
		{
			Connection con=null;
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver class loaded..");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j","root","root");
			System.out.println("connection established..");
			
			Statement stmt=con.createStatement();
			
			String qry="create table students(id_number int primary key,first_name varchar(20),second_name varchar(20) NOT NULL,year_of_study int,gender varchar(20),department varchar(3),mobile_number varchar(20),date_of_birth Date,parent_name varchar(20),parent_mobilenumber varchar(30),address varchar(20),proof_image BLOB,payemet_recepit LONGTEXT)";   
			stmt.executeUpdate(qry);
			System.out.println("Table is created..");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
